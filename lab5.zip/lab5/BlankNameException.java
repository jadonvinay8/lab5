package lab5;

public class BlankNameException extends Exception {
	
	public BlankNameException() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "BlankNameException: Name can't be blank";
	}
	
	
	
}
